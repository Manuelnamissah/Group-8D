# Breast Cancer Detection — Flutter frontend

Cross-platform mobile client for the BCDD system (Chapter 3.9 of the
documentation). Talks to the FastAPI backend in `../backend`.

## Run it

This repo ships only the Dart source (`lib/` + `pubspec.yaml`). Before the
first build, generate the missing platform folders (`android/`, `ios/`,
etc.) with:

```bash
flutter create . --project-name bcdd_app --org com.bcdd
flutter pub get
flutter run
```

`flutter create .` recognizes the existing `pubspec.yaml` and only adds
the platform scaffolding around your existing `lib/` — it won't overwrite
your code.

## Building app-release.apk

**Option A — locally**, once you've run the two commands above:
```bash
flutter build apk --release
```
Output lands at `build/app/outputs/flutter-apk/app-release.apk`.

**Option B — no local install**, via the included GitHub Actions
workflow (`.github/workflows/build_apk.yml`):
1. Push this project to a GitHub repo.
2. Open the repo's **Actions** tab → "Build release APK" → **Run workflow**
   (or just push a change under `frontend_flutter/`).
3. When the run finishes, download the `app-release-apk` artifact — that's
   your `app-release.apk`, no Flutter/Android SDK installed anywhere on
   your machine.

On first launch, open the settings (gear icon, top right) and set the
**Backend API base URL** to wherever `backend/` is deployed
(e.g. `http://10.0.2.2:8000` for an Android emulator hitting your laptop,
or `https://api.yourdomain.com` in production). It's saved locally with
`shared_preferences`.

## Structure

```
lib/
  main.dart                 # App shell, theme, brand colors
  screens/
    login_screen.dart       # Figure 3.3
    home_screen.dart        # Upload, analyze, result card, scan history
    settings_screen.dart    # API base URL configuration
  services/
    api_service.dart        # POST /predict, GET /health
  models/
    prediction.dart         # Response model + local ScanRecord
```

## Notes
- Login is a local UI gate only — no auth backend was specified in the
  project scope, so credentials aren't sent anywhere. Wire up a real
  auth endpoint if you add one.
- Scan history is kept in memory for the session; swap in `sqflite` or
  `shared_preferences` if you want it to persist across app restarts.
- Requires camera/photo library permissions on device — add the usual
  `NSPhotoLibraryUsageDescription` / `NSCameraUsageDescription` keys to
  `ios/Runner/Info.plist`, and the `READ_MEDIA_IMAGES`/`CAMERA`
  permissions to `android/app/src/main/AndroidManifest.xml`.

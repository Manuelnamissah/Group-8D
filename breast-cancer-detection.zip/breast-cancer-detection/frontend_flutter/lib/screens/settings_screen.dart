import 'package:flutter/material.dart';
import '../services/api_service.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _urlCtrl = TextEditingController();
  bool? _connected;
  bool _checking = false;

  @override
  void initState() {
    super.initState();
    ApiService.getBaseUrl().then((url) {
      if (url != null) _urlCtrl.text = url;
    });
  }

  Future<void> _saveAndCheck() async {
    setState(() => _checking = true);
    await ApiService.setBaseUrl(_urlCtrl.text);
    final ok = await ApiService.checkHealth();
    setState(() {
      _connected = ok;
      _checking = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('API settings')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Backend API base URL', style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 6),
            TextField(
              controller: _urlCtrl,
              decoration: const InputDecoration(
                hintText: 'https://api.yourdomain.com',
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.url,
            ),
            const SizedBox(height: 8),
            const Text(
              'Point this at the FastAPI backend from backend/, deployed per its README '
              '(VPS + Nginx, or Docker).',
              style: TextStyle(color: Colors.black54, fontSize: 12.5),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _checking ? null : _saveAndCheck,
              child: Text(_checking ? 'Checking…' : 'Save & test connection'),
            ),
            if (_connected != null) ...[
              const SizedBox(height: 12),
              Row(
                children: [
                  Icon(_connected! ? Icons.check_circle : Icons.error,
                      color: _connected! ? Colors.green : Colors.red, size: 18),
                  const SizedBox(width: 6),
                  Text(_connected! ? 'Connected' : 'Could not reach the API'),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }
}

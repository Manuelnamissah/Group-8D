class Prediction {
  final String label; // "benign" | "malignant" | "invalid"
  final double confidence; // 0..1
  final Map<String, double> probabilities;
  final bool demoMode;

  Prediction({
    required this.label,
    required this.confidence,
    required this.probabilities,
    required this.demoMode,
  });

  factory Prediction.fromJson(Map<String, dynamic> json) {
    final probsRaw = (json['probabilities'] as Map<String, dynamic>? ?? {});
    return Prediction(
      label: json['prediction'] as String? ?? 'invalid',
      confidence: (json['confidence'] as num?)?.toDouble() ?? 0.0,
      probabilities: probsRaw.map((k, v) => MapEntry(k, (v as num).toDouble())),
      demoMode: json['demo_mode'] as bool? ?? false,
    );
  }
}

/// A single row in the on-device scan history.
class ScanRecord {
  final String imagePath;
  final Prediction prediction;
  final DateTime timestamp;

  ScanRecord({
    required this.imagePath,
    required this.prediction,
    required this.timestamp,
  });
}

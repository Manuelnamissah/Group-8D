import 'dart:io';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../models/prediction.dart';

/// Talks to the FastAPI backend (see backend/README.md for deployment).
/// The base URL is configurable at runtime (Settings screen) and persisted
/// with SharedPreferences, so the same build can point at a local dev
/// server or the production VPS.
class ApiService {
  static const _prefsKey = 'api_base_url';

  static Future<String?> getBaseUrl() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_prefsKey);
  }

  static Future<void> setBaseUrl(String url) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_prefsKey, url.trim().replaceAll(RegExp(r'/+$'), ''));
  }

  static Future<bool> checkHealth() async {
    final base = await getBaseUrl();
    if (base == null || base.isEmpty) return false;
    try {
      final res = await http
          .get(Uri.parse('$base/health'))
          .timeout(const Duration(seconds: 6));
      return res.statusCode == 200;
    } catch (_) {
      return false;
    }
  }

  /// Uploads [imageFile] to POST /predict and parses the response.
  /// Throws an [ApiException] on network/HTTP failure so the UI can show
  /// a friendly "invalid" / retry state instead of crashing.
  static Future<Prediction> predict(File imageFile) async {
    final base = await getBaseUrl();
    if (base == null || base.isEmpty) {
      throw ApiException('No backend API URL configured. Set one in Settings.');
    }

    final uri = Uri.parse('$base/predict');
    final request = http.MultipartRequest('POST', uri)
      ..files.add(await http.MultipartFile.fromPath('file', imageFile.path));

    try {
      final streamed = await request.send().timeout(const Duration(seconds: 30));
      final body = await streamed.stream.bytesToString();

      if (streamed.statusCode != 200) {
        throw ApiException('Server returned ${streamed.statusCode}: $body');
      }
      final json = jsonDecode(body) as Map<String, dynamic>;
      return Prediction.fromJson(json);
    } on ApiException {
      rethrow;
    } catch (e) {
      throw ApiException('Could not reach the server: $e');
    }
  }
}

class ApiException implements Exception {
  final String message;
  ApiException(this.message);
  @override
  String toString() => message;
}

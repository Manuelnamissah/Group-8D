# Breast Cancer Detection System (BCDD)

Implementation of the system described in "Breast Cancer Detection Using
Deep Learning-Based MobileNetV2" — a CNN backend served over a REST API,
with two ready-to-use frontends.

```
breast-cancer-detection/
├── backend/                 FastAPI + MobileNetV2 (the API, Chapter 3.3/3.8)
│   ├── app/
│   │   ├── main.py          POST /predict, GET /health
│   │   ├── model.py         MobileNetV2 architecture + inference wrapper
│   │   └── schemas.py       Request/response models
│   ├── train_model.py       Trains the model on your BreakHis folders
│   ├── requirements.txt
│   ├── Dockerfile
│   └── README.md            Local run + VPS deployment (systemd/Nginx/Docker)
│
├── web_demo/
│   └── index.html           Standalone web interface (upload → analyze → result → history)
│
└── frontend_flutter/         Flutter mobile app (Chapter 3.9)
    ├── lib/
    │   ├── main.dart
    │   ├── screens/          login, home (upload/analyze/history), settings
    │   ├── services/         api_service.dart
    │   └── models/
    ├── pubspec.yaml
    └── README.md
```

## Quickest path to a working demo

1. **Backend**
   ```bash
   cd backend
   python -m venv venv && source venv/bin/activate
   pip install -r requirements.txt
   uvicorn app.main:app --reload --port 8000
   ```
   It starts immediately in **demo mode** (clearly labeled in every API
   response) so you can wire up the frontend before you've trained the
   real model. Train the real classifier with `train_model.py` once you
   have the BreakHis dataset prepared (see `backend/README.md`).

2. **Web frontend** — just open `web_demo/index.html` in a browser (or
   serve it with any static file server). Tap the gear icon and set the
   API URL to `http://localhost:8000`. Works with no backend at all too —
   it falls back to an in-browser demo predictor so the UI is fully
   explorable.

3. **Flutter app** (optional, matches the documented mobile frontend)
   ```bash
   cd frontend_flutter
   flutter pub get
   flutter run
   ```

## Going to production

Deploy `backend/` on your VPS behind Nginx (full steps in
`backend/README.md`, mirroring Chapter 3.8 of the documentation), train
a real model with `train_model.py` on your prepared BreakHis split, then
point either frontend's API URL setting at your production domain.

## What's real vs. what you still need to supply

| Piece | Status |
|---|---|
| API contract, preprocessing, model architecture | Implemented, matches Chapter 3.5/3.6 |
| Backend deployment (systemd/Nginx/Docker) | Implemented |
| Training script (augmentation, callbacks, eval report) | Implemented |
| **Trained weights file** (`model/*.keras`) | **Not included** — train it yourself on BreakHis, or the API safely runs in demo mode until you do |
| Web frontend (upload/analyze/history) | Implemented, fully working against a real or demo backend |
| Flutter mobile frontend | Implemented (login, upload/analyze/history, settings) |
| User accounts / auth backend | Out of scope per the documentation's stated scope — login screens are local-only placeholders |

## Safety note
This system is an educational/assistive tool, not a diagnostic device —
every interface in this project reflects that, and predictions should
always be reviewed by a qualified medical professional (see Chapter
3.12 of the documentation).

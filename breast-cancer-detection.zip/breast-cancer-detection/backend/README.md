# Breast Cancer Detection API (backend)

FastAPI + Uvicorn backend implementing the architecture from Chapter 3 of
the project documentation: a MobileNetV2 transfer-learning model behind a
single `POST /predict` endpoint, deployed on a VPS.

```
Mobile / Web App  --HTTP-->  FastAPI (/predict)  --calls-->  MobileNetV2 model  -->  JSON result
```

## 1. Run it locally

```bash
cd backend
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

Open http://localhost:8000/docs for interactive Swagger docs, or test with curl:

```bash
curl -X POST http://localhost:8000/predict \
  -F "file=@sample_histopathology_image.png"
```

Response:
```json
{
  "prediction": "malignant",
  "confidence": 0.82,
  "probabilities": {"benign": 0.11, "malignant": 0.82, "invalid": 0.07},
  "inference_time_ms": 42.3,
  "demo_mode": false
}
```

### About "demo mode"
This repo ships **code**, not the ~90MB trained weights file (that's a
training artifact, not source). Until you train and place a real model
file, `GET /health` and every `/predict` response will report
`"demo_mode": true` and predictions come from a placeholder, not a
trained network — see `app/model.py` for exactly what that means. Train a
real model with the steps below to turn this off.

## 2. Train the real model

You need the BreakHis dataset (Spanhol et al., 2016), split into
`train/`, `val/`, `test/` folders, each containing `benign/`,
`malignant/`, `invalid/` subfolders of 40x images (see `train_model.py`
docstring for the exact layout, and Chapter 3.4/3.5 of the documentation
for how the dataset was regrouped and preprocessed).

```bash
pip install -r requirements.txt   # includes tensorflow + scikit-learn
python train_model.py --data-dir ./data --epochs 20 --batch-size 32
```

This saves `model/breast_cancer_mobilenetv2.keras` and prints a
classification report + confusion matrix, matching Chapter 4 of the
documentation. Restart the API afterwards — it auto-detects the file.

## 3. Deploy to a VPS (matches Chapter 3.8)

### Option A — plain systemd + Nginx

```bash
# On the VPS
sudo apt update && sudo apt install -y python3-venv nginx
git clone <your-repo-url> /opt/bcdd-backend
cd /opt/bcdd-backend/backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

Create `/etc/systemd/system/bcdd-api.service`:

```ini
[Unit]
Description=Breast Cancer Detection API
After=network.target

[Service]
User=www-data
WorkingDirectory=/opt/bcdd-backend/backend
Environment="MODEL_PATH=/opt/bcdd-backend/backend/model/breast_cancer_mobilenetv2.keras"
ExecStart=/opt/bcdd-backend/backend/venv/bin/uvicorn app.main:app --host 127.0.0.1 --port 8000 --workers 2
Restart=always

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now bcdd-api
```

Nginx reverse proxy (`/etc/nginx/sites-available/bcdd-api`):

```nginx
server {
    listen 80;
    server_name api.yourdomain.com;

    client_max_body_size 12M;   # allow image uploads

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

```bash
sudo ln -s /etc/nginx/sites-available/bcdd-api /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx
sudo certbot --nginx -d api.yourdomain.com   # HTTPS
```

Point the Flutter app / web frontend's API base URL at
`https://api.yourdomain.com`.

### Option B — Docker

```bash
docker build -t bcdd-api .
docker run -d -p 8000:8000 -v $(pwd)/model:/srv/app/model --name bcdd-api bcdd-api
```

Then put Nginx (as above) in front of port 8000.

## 4. API reference

| Method | Path       | Description                                    |
|--------|-----------|-------------------------------------------------|
| GET    | `/health`  | Service + model status                          |
| POST   | `/predict` | multipart file upload (`file`) -> classification |

`/predict` accepts JPEG/PNG/WEBP up to 10 MB and returns the class
(`benign`, `malignant`, or `invalid`), confidence, and full probability
breakdown — see `app/schemas.py`.

## Ethical / safety notes (Chapter 3.12)
- Educational / assistive tool only — not a diagnostic device.
- No uploaded images or predictions are persisted server-side by default.
- Every response should be reviewed by a qualified medical professional.

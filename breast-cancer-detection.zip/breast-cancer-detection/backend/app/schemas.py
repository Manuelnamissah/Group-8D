from typing import Dict, List

from pydantic import BaseModel, Field


class PredictionResponse(BaseModel):
    prediction: str = Field(..., description="Top predicted class label.")
    confidence: float = Field(..., description="Confidence of the top class, 0-1.")
    probabilities: Dict[str, float] = Field(
        ..., description="Probability for every class, 0-1."
    )
    inference_time_ms: float = Field(..., description="Server-side inference time.")
    demo_mode: bool = Field(
        ...,
        description=(
            "True if no trained weights were found and the API is returning "
            "randomized placeholder predictions for demonstration purposes."
        ),
    )

    class Config:
        json_schema_extra = {
            "example": {
                "prediction": "malignant",
                "confidence": 0.82,
                "probabilities": {"benign": 0.11, "malignant": 0.82, "invalid": 0.07},
                "inference_time_ms": 42.3,
                "demo_mode": False,
            }
        }


class HealthResponse(BaseModel):
    status: str
    model_loaded: bool
    demo_mode: bool
    classes: List[str]

"""
Model architecture and inference wrapper for the Breast Cancer Detection
System (BCDD), matching Chapter 3.6.2 of the project documentation:

    Input(224, 224, 3)
      -> MobileNetV2 (ImageNet weights, transfer learning)
      -> GlobalAveragePooling2D
      -> Dropout(rate)
      -> Dense(3, activation="softmax")   # benign, malignant, invalid

IMPORTANT — about weights:
This repository ships the *architecture* and a working inference server.
It does NOT ship the ~90MB trained ``.keras`` weights file produced by
``train_model.py`` on the BreakHis dataset, since that file is a training
artifact, not source code. To go live with real predictions:

    1. Run `train_model.py` against your prepared BreakHis folders
       (see that script's docstring), which will save
       `model/breast_cancer_mobilenetv2.keras`.
    2. Restart the API. It will detect the file and load it automatically.

Until a trained weights file is present, the API runs in **demo mode**:
predictions are generated from simple, deterministic image statistics
(not a trained network) purely so the frontend has something to talk to
during development. `demo_mode: true` is always included in API responses
so this is never silently mistaken for a real diagnosis.
"""

from __future__ import annotations

import hashlib
import logging
import os
import threading
from pathlib import Path
from typing import Dict, Tuple

import numpy as np
from PIL import Image

logger = logging.getLogger("bcdd.model")

CLASS_NAMES = ["benign", "malignant", "invalid"]
IMAGE_SIZE = (224, 224)
DEFAULT_MODEL_PATH = Path(
    os.environ.get("MODEL_PATH", Path(__file__).resolve().parent.parent / "model" / "breast_cancer_mobilenetv2.keras")
)


class ModelNotLoadedError(RuntimeError):
    """Raised when a prediction is requested but no model could be initialized."""


def build_model(dropout_rate: float = 0.3, fine_tune: bool = False):
    """
    Builds the MobileNetV2-based classifier described in the documentation.
    Imports TensorFlow lazily so the rest of the API can still be imported /
    tested in environments without TF installed.
    """
    import tensorflow as tf
    from tensorflow.keras import layers, models

    base_model = tf.keras.applications.MobileNetV2(
        input_shape=(*IMAGE_SIZE, 3),
        include_top=False,
        weights="imagenet",
    )
    base_model.trainable = fine_tune

    inputs = layers.Input(shape=(*IMAGE_SIZE, 3))
    x = base_model(inputs, training=False)
    x = layers.GlobalAveragePooling2D()(x)
    x = layers.Dropout(dropout_rate)(x)
    outputs = layers.Dense(len(CLASS_NAMES), activation="softmax")(x)

    model = models.Model(inputs, outputs, name="bcdd_mobilenetv2")
    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=1e-4),
        loss="categorical_crossentropy",
        metrics=["accuracy"],
    )
    return model


class Predictor:
    """Wraps either a real trained Keras model or a deterministic demo stub."""

    def __init__(self, model_path: Path = DEFAULT_MODEL_PATH):
        self.model_path = model_path
        self.demo_mode = True
        self._model = None

        if model_path.exists():
            try:
                import tensorflow as tf

                self._model = tf.keras.models.load_model(model_path)
                self.demo_mode = False
                logger.info("Loaded trained model from %s", model_path)
            except Exception:
                logger.exception(
                    "Found %s but failed to load it. Falling back to demo mode.",
                    model_path,
                )
        else:
            logger.warning(
                "No trained model found at %s — serving DEMO MODE predictions. "
                "Run train_model.py to produce a real model file.",
                model_path,
            )

    # -- preprocessing -----------------------------------------------------
    @staticmethod
    def _preprocess(image: Image.Image) -> np.ndarray:
        """Resize to 224x224 and rescale to [0,1], matching Chapter 3.5."""
        resized = image.resize(IMAGE_SIZE)
        array = np.asarray(resized, dtype=np.float32) / 255.0
        return np.expand_dims(array, axis=0)

    # -- inference -----------------------------------------------------------
    def predict(self, image: Image.Image) -> Tuple[str, float, Dict[str, float]]:
        if self._model is not None:
            batch = self._preprocess(image)
            raw = self._model.predict(batch, verbose=0)[0]
            probs = {name: float(p) for name, p in zip(CLASS_NAMES, raw)}
        else:
            probs = self._demo_probabilities(image)

        top_label = max(probs, key=probs.get)
        return top_label, probs[top_label], probs

    @staticmethod
    def _demo_probabilities(image: Image.Image) -> Dict[str, float]:
        """
        Deterministic (same image -> same result) placeholder so the
        frontend behaves sensibly during development without real weights.
        Uses basic pixel statistics + a hash of the image bytes as a seed —
        this is NOT a trained model and must never be presented as one.
        """
        small = image.resize((32, 32)).convert("RGB")
        arr = np.asarray(small, dtype=np.float32)
        digest = hashlib.sha256(arr.tobytes()).digest()
        seed = int.from_bytes(digest[:4], "big")
        rng = np.random.default_rng(seed)

        # Very low color variance / near-uniform images -> "invalid"
        color_std = float(arr.std())
        if color_std < 8.0:
            base = np.array([0.03, 0.02, 0.95])
        else:
            base = rng.dirichlet(alpha=[4.0, 3.0, 0.3])

        noisy = base + rng.normal(0, 0.03, size=3)
        noisy = np.clip(noisy, 1e-3, None)
        noisy = noisy / noisy.sum()
        return {name: float(p) for name, p in zip(CLASS_NAMES, noisy)}


_predictor_lock = threading.Lock()
_predictor_instance: Predictor | None = None


def get_predictor() -> Predictor:
    """Singleton accessor so the (potentially large) model loads only once."""
    global _predictor_instance
    if _predictor_instance is None:
        with _predictor_lock:
            if _predictor_instance is None:
                _predictor_instance = Predictor()
    return _predictor_instance

"""
Breast Cancer Detection API
============================
FastAPI backend that serves the MobileNetV2-based breast cancer detection
model described in the project documentation (BCDD system).

Endpoints
---------
GET  /health          -> service + model status check
POST /predict          -> classify a single histopathology image
                           (multipart/form-data, field name: "file")

Run locally:
    uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload

Run in production (on the VPS), see README.md for the systemd + nginx setup.
"""

import io
import logging
import time
from typing import Dict

import numpy as np
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from PIL import Image, UnidentifiedImageError

from app.model import CLASS_NAMES, ModelNotLoadedError, get_predictor
from app.schemas import HealthResponse, PredictionResponse

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("bcdd")

app = FastAPI(
    title="Breast Cancer Detection API",
    description=(
        "Classifies breast histopathology images (40x magnification) as "
        "benign, malignant, or invalid using a MobileNetV2 transfer-learning "
        "model. Educational / assistive tool only — not a substitute for "
        "clinical diagnosis."
    ),
    version="1.0.0",
)

# Allow the Flutter app / web frontend to call this API from any origin.
# Tighten allow_origins to your app's domain(s) once you go to production.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

MAX_UPLOAD_BYTES = 10 * 1024 * 1024  # 10 MB
ALLOWED_CONTENT_TYPES = {"image/jpeg", "image/png", "image/jpg", "image/webp"}


@app.on_event("startup")
async def load_model_on_startup() -> None:
    """Load the trained model once, at process start, instead of per-request."""
    try:
        predictor = get_predictor()
        logger.info(
            "Model loaded successfully (demo_mode=%s).", predictor.demo_mode
        )
    except Exception:  # noqa: BLE001 — we want the server to still boot
        logger.exception(
            "Model failed to load. /predict will return 503 until this is fixed."
        )


@app.get("/", include_in_schema=False)
async def root() -> Dict[str, str]:
    return {"message": "Breast Cancer Detection API — see /docs for usage."}


@app.get("/health", response_model=HealthResponse)
async def health() -> HealthResponse:
    try:
        predictor = get_predictor()
        return HealthResponse(
            status="ok",
            model_loaded=True,
            demo_mode=predictor.demo_mode,
            classes=CLASS_NAMES,
        )
    except ModelNotLoadedError:
        return HealthResponse(
            status="degraded",
            model_loaded=False,
            demo_mode=False,
            classes=CLASS_NAMES,
        )


@app.post("/predict", response_model=PredictionResponse)
async def predict(file: UploadFile = File(...)) -> PredictionResponse:
    """
    Classify a single uploaded histopathology image.

    Mirrors the API contract described in the project documentation:
        {"prediction": "malignant", "confidence": 0.82}
    (this implementation additionally returns the full per-class
    probability breakdown, which the mobile app / frontend can ignore
    if it only needs the top prediction).
    """
    if file.content_type not in ALLOWED_CONTENT_TYPES:
        raise HTTPException(
            status_code=415,
            detail=f"Unsupported file type '{file.content_type}'. "
            f"Upload a JPEG, PNG or WEBP image.",
        )

    raw_bytes = await file.read()
    if len(raw_bytes) > MAX_UPLOAD_BYTES:
        raise HTTPException(status_code=413, detail="Image exceeds 10 MB limit.")

    try:
        image = Image.open(io.BytesIO(raw_bytes)).convert("RGB")
    except UnidentifiedImageError as exc:
        raise HTTPException(
            status_code=400, detail="File could not be read as an image."
        ) from exc

    try:
        predictor = get_predictor()
    except ModelNotLoadedError as exc:
        raise HTTPException(
            status_code=503,
            detail="Model is not available on the server right now.",
        ) from exc

    start = time.perf_counter()
    label, confidence, probabilities = predictor.predict(image)
    elapsed_ms = (time.perf_counter() - start) * 1000

    logger.info(
        "Prediction: %s (%.2f%%) in %.1fms — file=%s size=%d bytes",
        label,
        confidence * 100,
        elapsed_ms,
        file.filename,
        len(raw_bytes),
    )

    return PredictionResponse(
        prediction=label,
        confidence=round(confidence, 4),
        probabilities={k: round(v, 4) for k, v in probabilities.items()},
        inference_time_ms=round(elapsed_ms, 1),
        demo_mode=predictor.demo_mode,
    )
